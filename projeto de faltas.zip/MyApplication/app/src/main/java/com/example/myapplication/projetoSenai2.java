package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class projetoSenai2 extends AppCompatActivity {

    private TextView Txt_anunciado;
    private ImageButton Btn_faltas;
    private EditText Edt_notificacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projeto_senai2);

        Txt_anunciado = findViewById(R.id.Txt_anunciado);
        Btn_faltas = findViewById(R.id.Btn_faltas);
        Edt_notificacao = findViewById(R.id.Edt_notificacao);

        // Define um array de mensagens que indicam o estado de faltas.
        String[] mensagens = {
                "O estado de faltas não é crítico.",
                "O estado de faltas é crítico. Aja imediatamente.",
                "Verifique as faltas e tome ações apropriadas.",
                "Tudo está sob controle em relação às faltas.",
        };

        // Adiciona um clique ao botão para exibir uma mensagem aleatória.
        Btn_faltas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Gere um índice aleatório para selecionar uma mensagem do array.
                int indice = new Random().nextInt(mensagens.length);

                // Exiba a mensagem aleatória no EditText.
                Edt_notificacao.setText(mensagens[indice]);
            }
        });
    }
}
