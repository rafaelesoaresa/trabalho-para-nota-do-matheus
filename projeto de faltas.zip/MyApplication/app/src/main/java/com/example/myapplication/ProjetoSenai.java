package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProjetoSenai extends AppCompatActivity {

    private TextView Txt_titulo, Txt_introdution, Txt_introdoção2, Txt_informaçao;
    private EditText Edt_sintomas;
    private CheckBox cb_jst1, cb_jst2, cb_jst3, cb_jst4, cb_jst5, cb_jst6, cb_jst7, cb_jst8, cb_jst9;
    private ImageView Img_logo;
    private ImageButton Btn_justificar;
    private ImageButton Btn_segundaTela; // Botão para navegar para a segunda tela.

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Txt_titulo = findViewById(R.id.Txt_titulo);
        Txt_introdution = findViewById(R.id.Txt_introdution);
        Txt_introdoção2 = findViewById(R.id.Txt_introdoção2);
        Txt_informaçao = findViewById(R.id.Txt_informaçao);
        Edt_sintomas = findViewById(R.id.Edt_sintomas);
        cb_jst1 = findViewById(R.id.cb_jst1);
        cb_jst2 = findViewById(R.id.cb_jst2);
        cb_jst3 = findViewById(R.id.cb_jst3);
        cb_jst4 = findViewById(R.id.cb_jst4);
        cb_jst5 = findViewById(R.id.cb_jst5);
        cb_jst6 = findViewById(R.id.cb_jst6);
        cb_jst7 = findViewById(R.id.cb_jst7);
        cb_jst8 = findViewById(R.id.cb_jst8);
        cb_jst9 = findViewById(R.id.cb_jst9);
        Btn_justificar = findViewById(R.id.Btn_justificar);

        Btn_justificar = findViewById(R.id.Btn_justificar);
        Btn_justificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProjetoSenai.this, projetoSenai2.class);
                startActivity(intent);
            }
        });


        Btn_justificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder justifications = new StringBuilder();

                if (cb_jst1.isChecked()) {
                    justifications.append(cb_jst1.getText()).append("\n");
                }
                if (cb_jst2.isChecked()) {
                    justifications.append(cb_jst2.getText()).append("\n");
                }
                if (cb_jst3.isChecked()) {
                    justifications.append(cb_jst3.getText()).append("\n");
                }
                if (cb_jst4.isChecked()) {
                    justifications.append(cb_jst4.getText()).append("\n");
                }
                if (cb_jst5.isChecked()) {
                    justifications.append(cb_jst5.getText()).append("\n");
                }
                if (cb_jst6.isChecked()) {
                    justifications.append(cb_jst6.getText()).append("\n");
                }
                if (cb_jst7.isChecked()) {
                    justifications.append(cb_jst7.getText()).append("\n");
                }
                if (cb_jst8.isChecked()) {
                    justifications.append(cb_jst8.getText()).append("\n");
                }
                if (cb_jst9.isChecked()) {
                    justifications.append(cb_jst9.getText()).append("\n");
                }

                showJustificationDialog(justifications.toString());
            }
        });
    }

    private void showJustificationDialog(String justificationText) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Justificação Confirmada");
        builder.setMessage("Você justificou as seguintes faltas:\n\n" + justificationText);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Ação após o usuário confirmar a justificação, se necessário.
            }
        });
        builder.show();
    }
}
